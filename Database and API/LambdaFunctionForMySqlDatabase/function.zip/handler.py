import pymysql

# 1. Install pymysql to local directory
# pip install -t $PWD pymysql

# 2. (If using Lambda) Write your code, then zip it all up
#   a) Mac/Linux  --> zip -r9 ${PWD}/function.zip
#   b) Window --> Via Windows

# Configuration values:
endpoint = 'tomato-virus-1.chavbdc9w8gh.us-east-1.rds.amazonaws.com'
username = 'hoyyang'
password = 'tomatovirus123'
database_name = 'tomatovirus_mysql_db'

# Connection
connection = pymysql.connect(endpoint, user=username, passwd=password, db=database_name)


def lambda_handler(event, context):
    cursor = connection.cursor()
    cursor.execute('SELECT * from virus')

    rows = cursor.fetchall()

    for row in rows:
        print("{0} {1} {2} {3} {4} {5} {6}".format(row[0],row[1],row[2],row[3],row[4],row[5],row[6]))
